# Junie AI Assistant Guidelines

This file provides context for the Junie AI assistant (JetBrains) when contributing to OWASP Juice Shop.

**Important**: The primary authoritative source for all AI contributions is the [root AGENTS.md](../AGENTS.md). Please refer to that file for comprehensive guidelines, project overview, and shared skills.

**Skill Discovery**: Before performing any task, check if a matching skill exists by reading the `Skills` section of [AGENTS.md](../AGENTS.md). If a relevant skill is found, read and follow its `SKILL.md` from `.ai/skills/` before proceeding.
